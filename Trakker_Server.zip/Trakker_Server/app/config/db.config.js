module.exports = {
	host: 'localhost',
	user: 'root',
	password: 'noah2745',
	database: 'trakker'
};