const sql = require("./db.js");

// constructor
const ListToMovies = function(list) {
  this.ListId = list.ListId;
  this.MovieId = list.MovieId;
};

ListToMovies.create = (newList, result) => {
  sql.query("INSERT INTO liststomovies SET ?", newList, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("created list: ", { id: res.insertId, ...newList });
    result(null, { id: res.insertId, ...newList });
  });
};

ListToMovies.remove = (id, result) => {
  sql.query("DELETE FROM liststomovies WHERE id= ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted list with id: ", id);
    result(null, res);
  });
};

module.exports = ListToMovies;