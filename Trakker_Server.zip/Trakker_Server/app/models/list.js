const sql = require("./db.js");

// constructor
const List = function(list) {
  this.UserId = list.UserId;
  this.ListName = list.ListName;
};

List.create = (newList, result) => {
  sql.query("INSERT INTO lists SET ?", newList, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("created list: ", { id: res.insertId, ...newList });
    result(null, { id: res.insertId, ...newList });
  });
};

List.updateById = (id, list, result) => {
  sql.query(
    "UPDATE lists SET UserId = ?, ListName = ?",
    [list.UserId, list.ListName, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found Customer with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated list: ", { id: id, ...list });
      result(null, { id: id, ...list });
    }
  );
};

List.getListsByUserId = (id, result) => {
  sql.query(`SELECT * FROM lists where lists.UserId = ?`, id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("lists: ", res);
    result(null, res);
  });

}

List.remove = (id, result) => {
  sql.query("DELETE FROM lists WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted list with id: ", id);
    result(null, res);
  });
};

List.removeAll = result => {
  sql.query("DELETE FROM lists", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} lists`);
    result(null, res);
  });
};

module.exports = List;