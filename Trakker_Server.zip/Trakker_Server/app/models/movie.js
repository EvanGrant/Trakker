const sql = require("./db.js");

// constructor
const Movie = function(movie) {
  this.Email = movie.Title;
  this.Director = movie.Director;
  this.FirstName = movie.Genre;
  this.LastName = movie.Length;
  this.Password = movie.Description;
};

Movie.create = (newMovie, result) => {
  sql.query("INSERT INTO movies SET ?", newMovie, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("created movie: ", { id: res.insertId, ...newMovie });
    result(null, { id: res.insertId, ...newMovie });
  });
};

Movie.getMoviesByIds = (ListId, result) => {
  sql.query(`SELECT * FROM movies, liststomovies where liststomovies.ListId=${ListId} and movies.id=liststomovies.MovieId`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("movies: ", res);
    result(null, res);
  });

}

Movie.updateById = (id, result) => {
  sql.query(
    "UPDATE movies SET Title = ?, Director = ?, Genre = ?, Length = ?, Description = ? WHERE id = ?",
    [movie.Title, movie.Director, movie.Genre, movie.Length, movie.Description, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found Customer with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated movie: ", { id: id, ...movie });
      result(null, { id: id, ...movie });
    }
  );
};

Movie.remove = (id, result) => {
  sql.query("DELETE FROM movies WHERE id= ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted movie with id: ", movie);
    result(null, res);
  });
};

Movie.removeAll = result => {
  sql.query("DELETE FROM movies", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} movies`);
    result(null, res);
  });
};

module.exports = Movie;
