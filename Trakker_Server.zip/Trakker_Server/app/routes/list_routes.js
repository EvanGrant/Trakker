module.exports = app => {
    const list = require("../controllers/list_controller.js");
  
    // Create a new Customer
    app.post("/list", list.create);

    // Update a Customer with customerId
    app.put("/list/:id", list.update);

    // get all the lists of a certain user
    app.get("/lists/:id", list.getAll);

    // Delete a Customer with customerId
    app.delete("/list/:id", list.delete);

    // Create a new Customer
    app.delete("/list", list.deleteAll);

  };