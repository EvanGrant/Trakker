module.exports = app => {
    const movies = require("../controllers/movie_controller.js");
  
    // Create a new Customer
    app.post("/movies", movies.create);

    // Update a Customer with customerId
    app.put("/movies/:movieId", movies.update);

    // get movies from list with id
    app.get("/moviesfromlist/:id", movies.findMovies);

    // Delete a Customer with customerId
    app.delete("/movies/:movieId", movies.delete);

    // Create a new Customer
    app.delete("/movies", movies.deleteAll);

  };