module.exports = app => {
    const lists = require("../controllers/listToMovies_controller.js");
  
    // Create a new Customer
    app.post("/lists", lists.create);

    // Delete a list with id
    app.delete("/lists/:id", lists.delete);

    // delete all lists
    app.delete("/lists", lists.deleteAll);

  };