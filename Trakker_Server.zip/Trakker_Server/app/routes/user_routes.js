module.exports = app => {
    const users = require("../controllers/user_controller.js");
  
    // Create a new Customer
    app.post("/users", users.create);

  };