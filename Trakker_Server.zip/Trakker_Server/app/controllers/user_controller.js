const User = require("../models/user.js");

/*
// Retrieve all Customers from the database.
exports.findAll = (req, res) => {
  
};

// Find a single Customer with a customerId
exports.findOne = (req, res) => {
  
};

// Update a Customer identified by the customerId in the request
exports.update = (req, res) => {
  
};

// Delete a Customer with the specified customerId in the request
exports.delete = (req, res) => {
  
};

// Delete all Customers from the database.
exports.deleteAll = (req, res) => {
  
};
*/

exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a Customer
  const user = new User({
    Email: req.body.Email,
    FirstName: req.body.FirstName,
	  LastName: req.body.LastName,
    Password: req.body.Password
  });

  // Save Customer in the database
  User.create(user, (err, data) => {
    if(err != null && err.code == "ER_DUP_ENTRY")

       res.status(420).send({
         message:
          err.message || "Duplicate entry."
       });

    else if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the User."
      });
    else res.send(data);
  });
};