const Movie = require("../models/movie.js");

/*
// Retrieve all Customers from the database.
exports.findAll = (req, res) => {
  
};

// Find a single Customer with a customerId
exports.findOne = (req, res) => {
  
};

// Update a Customer identified by the customerId in the request
exports.update = (req, res) => {
  
};

// Delete a Customer with the specified customerId in the request
exports.delete = (req, res) => {
  
};

// Delete all Customers from the database.
exports.deleteAll = (req, res) => {
  
};
*/

exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a Customer
  const movie = new Movie({
    Title: req.body.Title,
    Director: req.body.Director,
	Genre: req.body.Genre,
    Length: req.body.Length,
    Description: req.body.Description
  });

  // Save Movie in the database
  Movie.create(movie, (err, data) => {
    if(err != null && err.code == "ER_DUP_ENTRY")

       res.status(420).send({
         message:
          err.message || "Duplicate entry."
       });

    else if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the User."
      });
    else res.send(data);
  });
};

exports.findMovies = (req, res) => {
  Movie.getMoviesByIds(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found movies from list with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving movies for list with id " + req.params.id
        });
      }
    } else res.send(data);
  });
};

exports.update = (req, res) => {
  // Validate Request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  Movie.updateById(
    req.params.id,
    new Movie(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Movie with id ${req.params.id}.`
          });
        } else {
          res.status(500).send({
            message: "Error updating Movie with id " + req.params.id
          });
        }
      } else res.send(data);
    }
  );
};


exports.delete = (req, res) => {
  Movie.remove(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Movie with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Movie with id " + req.params.id
        });
      }
    } else res.send({ message: `User was deleted successfully!` });
  });
};


exports.deleteAll = (req, res) => {
  Movie.removeAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all movies."
      });
    else res.send({ message: `All Users were deleted successfully!` });
  });
};