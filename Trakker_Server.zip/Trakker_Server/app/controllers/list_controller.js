const List = require("../models/list.js");

/*
// Retrieve all Customers from the database.
exports.findAll = (req, res) => {
  
};

// Find a single Customer with a customerId
exports.findOne = (req, res) => {
  
};

// Update a Customer identified by the customerId in the request
exports.update = (req, res) => {
  
};

// Delete a Customer with the specified customerId in the request
exports.delete = (req, res) => {
  
};

// Delete all Customers from the database.
exports.deleteAll = (req, res) => {
  
};
*/

exports.create = (req, res) => {
    // Validate request
    if (!req.body) {
      res.status(400).send({
        message: "Content can not be empty!"
      });
    }
  
    // Create a list
    const list = new List({
      UserId: req.body.UserId,
      ListName: req.body.ListName,
    });
  
    // Save List in the database
    List.create(list, (err, data) => {
      if(err != null && err.code == "ER_DUP_ENTRY")
  
         res.status(420).send({
           message:
            err.message || "Duplicate entry."
         });
  
      else if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the List."
        });
      else res.send(data);
    });
  };
  
  exports.update = (req, res) => {
    // Validate Request
    if (!req.body) {
      res.status(400).send({
        message: "Content can not be empty!"
      });
    }
  
    List.updateById(
      req.params.id,
      new User(req.body),
      (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found List with id ${req.params.id}.`
            });
          } else {
            res.status(500).send({
              message: "Error updating List with id " + req.params.id
            });
          }
        } else res.send(data);
      }
    );
  };

  exports.getAll = (req, res) => {
    List.getListsByUserId(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found lists from user with id ${req.params.id}.`
          });
        } else {
          res.status(500).send({
            message: "Error retrieving lists from user with id " + req.params.id
          });
        }
      } else res.send(data);
    });
  };
  
  exports.delete = (req, res) => {
    List.remove(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found List with id ${req.params.id}.`
          });
        } else {
          res.status(500).send({
            message: "Could not delete list with id " + req.params.id
          });
        }
      } else res.send({ message: `list was deleted successfully!` });
    });
  };

  exports.deleteAll = (req, res) => {
    List.removeAll((err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while removing all lists."
        });
      else res.send({ message: `All Lists were deleted successfully!` });
    });
  };